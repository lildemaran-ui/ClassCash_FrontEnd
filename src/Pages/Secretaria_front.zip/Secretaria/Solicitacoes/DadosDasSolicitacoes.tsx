import Avatar from "@/components/Avatar/Avatar";
import { Header } from "@/components/Header/header";
import MenuSecretaria from "@/components/Menu/MenuSecretaria";
import { fetchComAuth } from "@/types/global/fetchComAuth";
import {
  exigirSessao,
  getToken,
  type SessaoUsuario,
} from "@/types/global/sessao";
import {
  AlertCircle,
  CheckCircle,
  CircleUser,
  Clock,
  Eye,
  Key,
  Search,
  UserCheck,
  UserX,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";

const API = "http://localhost:5000/api";

interface Solicitacao {
  tipo: "estudante" | "encarregado";
  id: number;
  nome: string;
  email: string;
  contacto: string | null;
  num_processo: string;
  status: string;
  codigo_plataforma: string | null;
  instituicao: string;
  classe?: number;
  grau_parentesco?: string;
  nome_educando?: string;
}

export default function DadosDasSolicitacoes() {
  const [codigo, setCodigo] = useState("");
  const [motivo, setMotivo] = useState("");
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState("");

  function ModalDetalhes({
    item,
    onClose,
    onApproved,
    onRejected,
    initialTab,
  }: {
    item: Solicitacao;
    onClose: () => void;
    onApproved: (id: number, tipo: string, codigo: string) => void;
    onRejected: (id: number, tipo: string) => void;
    initialTab: "detalhes" | "aprovar" | "recusar";
  }) {
    const [tab, setTab] = useState<"detalhes" | "aprovar" | "recusar">(
      initialTab,
    );

    const aprovar = async () => {
      setLoading(true);
      setErro("");
      try {
        const token = getToken();
        const res = await fetchComAuth(`${API}/aprovacao/aprovar`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            tipo: item.tipo,
            id: item.id,
            codigoCustom: codigo,
          }),
        });
        const data = (await res.json()) as { codigo?: string; error?: string };
        if (!res.ok) throw new Error(data.error ?? "Erro ao aprovar");
        onApproved(item.id, item.tipo, data.codigo ?? "");
        onClose();
      } catch (e) {
        setErro(e instanceof Error ? e.message : "Erro");
      } finally {
        setLoading(false);
      }
    };

    const recusar = async () => {
      if (!motivo.trim()) {
        setErro("Indica o motivo da recusa.");
        return;
      }
      setLoading(true);
      setErro("");
      try {
        const token = getToken();
        const res = await fetchComAuth(`${API}/aprovacao/recusar`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ tipo: item.tipo, id: item.id, motivo }),
        });
        const data = (await res.json()) as { error?: string };
        if (!res.ok) throw new Error(data.error ?? "Erro ao recusar");
        onRejected(item.id, item.tipo);
        onClose();
      } catch (e) {
        setErro(e instanceof Error ? e.message : "Erro");
      } finally {
        setLoading(false);
      }
    };

    return (
      <div
        className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-0 sm:p-4"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <div className="bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl w-full sm:max-w-lg overflow-hidden max-h-[95dvh] flex flex-col">
          {/* Header do Modal */}
          <div className="flex justify-between items-center p-4 sm:p-6 border-b shrink-0">
            <div className="min-w-0 pr-2">
              <h2 className="font-bold text-gray-800 text-sm sm:text-base truncate">
                Solicitação de Cadastro
              </h2>
              <p className="text-xs text-gray-500 mt-0.5 truncate">
                {item.nome} · {item.instituicao}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-gray-100 shrink-0"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {/* Abas */}
          <div className="flex border-b shrink-0">
            {(["detalhes", "aprovar", "recusar"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 py-2.5 text-[11px] sm:text-xs font-semibold capitalize transition-colors ${tab === t ? "border-b-2 border-[#184d8a] text-[#184d8a]" : "text-gray-400 hover:text-gray-600"}`}
              >
                {t === "detalhes"
                  ? "Ver Dados"
                  : t === "aprovar"
                    ? "✅ Aprovar"
                    : "❌ Recusar"}
              </button>
            ))}
          </div>

          {/* Conteúdo com scroll */}
          <div className="p-4 sm:p-6 overflow-y-auto">
            {tab === "detalhes" && (
              <div className="space-y-3">
                <div className="grid grid-cols-1 xs:grid-cols-2 gap-3">
                  {[
                    ["Nome", item.nome],
                    ["Email", item.email],
                    ["Contacto", item.contacto ?? "—"],
                    ["Nº Processo", item.num_processo],
                    ["Instituição", item.instituicao],
                    [
                      "Tipo",
                      item.tipo === "estudante" ? "Estudante" : "Encarregado",
                    ],
                    ...(item.classe ? [["Classe", `${item.classe}ª`]] : []),
                    ...(item.grau_parentesco
                      ? [["Parentesco", item.grau_parentesco]]
                      : []),
                    ...(item.nome_educando
                      ? [["Educando", item.nome_educando]]
                      : []),
                  ].map(([label, value]) => (
                    <div key={label} className="bg-gray-50 rounded-xl p-3">
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide">
                        {label}
                      </p>
                      <p className="text-sm font-semibold text-gray-800 mt-0.5 break-words">
                        {value}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-700">
                    A senha <strong>não é visível</strong> por segurança.
                  </p>
                </div>
              </div>
            )}

            {tab === "aprovar" && (
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-green-800">
                      Aprovar cadastro
                    </p>
                    <p className="text-xs text-green-700 mt-1">
                      Ao aprovar, será gerado um código único e um email enviado
                      automaticamente.
                    </p>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-1 flex items-center gap-1">
                    <Key className="w-3.5 h-3.5" /> Código personalizado
                  </label>
                  <input
                    disabled
                    type="text"
                    placeholder="Ex: CC-2026-A1B2"
                    value={codigo}
                    onChange={(e) => setCodigo(e.target.value)}
                    className="w-full border border-gray-300 rounded-xl p-2.5 text-sm focus:ring-2 focus:ring-green-400 outline-none"
                  />
                </div>
                {erro && (
                  <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg p-2">
                    {erro}
                  </p>
                )}
                <button
                  onClick={aprovar}
                  disabled={loading}
                  className="w-full bg-green-600 text-white font-bold py-3 rounded-xl hover:bg-green-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2 text-sm"
                >
                  <UserCheck className="w-4 h-4" />
                  {loading ? "A aprovar..." : "Confirmar Aprovação"}
                </button>
              </div>
            )}

            {tab === "recusar" && (
              <div className="space-y-4">
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
                  <UserX className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-red-800">
                      Recusar cadastro
                    </p>
                    <p className="text-xs text-red-700 mt-1">
                      O utilizador receberá um email com o motivo indicado.
                    </p>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Motivo da recusa <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Ex: Dados incorrectos, estudante não reconhecido..."
                    value={motivo}
                    onChange={(e) => setMotivo(e.target.value)}
                    className="w-full border border-gray-300 rounded-xl p-2.5 text-sm focus:ring-2 focus:ring-red-400 outline-none resize-none"
                  />
                </div>
                {erro && (
                  <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg p-2">
                    {erro}
                  </p>
                )}
                <button
                  onClick={recusar}
                  disabled={loading}
                  className="w-full bg-red-600 text-white font-bold py-3 rounded-xl hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2 text-sm"
                >
                  <UserX className="w-4 h-4" />
                  {loading ? "A recusar..." : "Confirmar Recusa"}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  const [solicitacoes, setSolicitacoes] = useState<Solicitacao[]>([]);
  const [user, setUser] = useState<SessaoUsuario | null>(null);
  const [search, setSearch] = useState("");
  const [filtroTipo, setFiltroTipo] = useState<
    "todos" | "estudante" | "encarregado"
  >("todos");
  const [selected, setSelected] = useState<{
    item: Solicitacao;
    tab: "detalhes" | "aprovar" | "recusar";
  } | null>(null);

  const carregar = async () => {
    setLoading(true);
    try {
      const token = getToken();
      const res = await fetchComAuth(`${API}/aprovacao/pendentes`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = (await res.json()) as {
        estudantes: Solicitacao[];
        encarregados: Solicitacao[];
      };
      setSolicitacoes([...data.estudantes, ...data.encarregados]);
    } catch (e) {
      console.error("Erro ao carregar pendentes", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const sessao = exigirSessao();
    if (sessao) setUser(sessao.usuario);
    carregar();
  }, []);

  const handleApproved = (id: number, tipo: string) =>
    setSolicitacoes((prev) =>
      prev.filter((s) => !(s.id === id && s.tipo === tipo)),
    );
  const handleRejected = (id: number, tipo: string) =>
    setSolicitacoes((prev) =>
      prev.filter((s) => !(s.id === id && s.tipo === tipo)),
    );

  const filtradas = solicitacoes.filter((s) => {
    const matchTipo = filtroTipo === "todos" || s.tipo === filtroTipo;
    const matchSearch =
      s.nome.toLowerCase().includes(search.toLowerCase()) ||
      s.email.toLowerCase().includes(search.toLowerCase()) ||
      s.instituicao.toLowerCase().includes(search.toLowerCase());
    return matchTipo && matchSearch;
  });

  if (!user) return null;

  return (
    <div className="flex h-screen bg-gray-50 font-sans overflow-hidden custom_scroll">
      <MenuSecretaria />

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header
          titulo="Solicitações de Cadastro"
          usuario={<Avatar name={user.nome} src={user.foto} size="sm" />}
        />

        <main className="p-4 sm:p-6 md:p-8 space-y-4 sm:space-y-5 overflow-y-auto">
          {/* Filtros + Pesquisa */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            {/* Filtros de tipo */}
            <div className="flex gap-2 flex-wrap">
              {(["todos", "estudante", "encarregado"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFiltroTipo(f)}
                  className={`text-xs font-semibold px-3 sm:px-4 py-1.5 rounded-full border transition-colors capitalize ${
                    filtroTipo === f
                      ? "bg-primary text-white border-[#184d8a]"
                      : "bg-white text-gray-500 border-gray-200 hover:border-[#184d8a] hover:text-[#184d8a]"
                  }`}
                >
                  {f === "todos"
                    ? "Todos"
                    : f === "estudante"
                      ? "Estudantes"
                      : "Encarregados"}
                </button>
              ))}
            </div>

            {/* Campo de pesquisa */}
            <div className="relative w-full sm:w-auto">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Pesquisar..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 pr-4 py-2 w-full sm:w-56 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#184d8a]/20 outline-none text-sm"
              />
            </div>
          </div>

          {/* Estados: loading / vazio / lista */}
          {loading ? (
            <div className="flex items-center justify-center py-20 text-gray-400">
              <Clock className="w-6 h-6 animate-spin mr-2" /> A carregar
              solicitações...
            </div>
          ) : filtradas.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
              <CheckCircle className="w-12 h-12 mb-3 opacity-30 text-green-500" />
              <p className="text-sm font-medium">
                Nenhuma solicitação pendente
              </p>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              {/* Cabeçalho da tabela */}
              <div className="px-4 sm:px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <h2 className="font-bold text-gray-800 text-sm">
                  Solicitações Pendentes
                </h2>
                <span className="text-xs bg-amber-50 text-amber-700 font-semibold px-3 py-1 rounded-full border border-amber-200">
                  {filtradas.length} por tratar
                </span>
              </div>

              {/* Lista de solicitações */}
              <div className="divide-y divide-gray-50">
                {filtradas.map((s) => (
                  <div
                    key={`${s.tipo}-${s.id}`}
                    className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 px-4 sm:px-6 py-4 hover:bg-gray-50 transition-colors"
                  >
                    {/* Ícone + Info */}
                    <div className="flex items-center gap-3 sm:gap-4 flex-1 min-w-0">
                      <div
                        className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          s.tipo === "estudante"
                            ? "bg-blue-50 border border-blue-100"
                            : "bg-purple-50 border border-purple-100"
                        }`}
                      >
                        <CircleUser
                          className={`w-4 h-4 sm:w-5 sm:h-5 ${s.tipo === "estudante" ? "text-blue-500" : "text-purple-500"}`}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-bold text-gray-900 truncate">
                            {s.nome}
                          </p>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                              s.tipo === "estudante"
                                ? "bg-blue-100 text-blue-700"
                                : "bg-purple-100 text-purple-700"
                            }`}
                          >
                            {s.tipo === "estudante"
                              ? "Estudante"
                              : "Encarregado"}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 mt-0.5 truncate">
                          {s.email} · {s.instituicao}
                        </p>
                        {s.nome_educando && (
                          <p className="text-xs text-gray-400 mt-0.5">
                            Educando: {s.nome_educando}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Botões de ação */}
                    <div className="flex items-center gap-2 sm:shrink-0 pl-12 sm:pl-0">
                      <button
                        onClick={() =>
                          setSelected({ item: s, tab: "detalhes" })
                        }
                        className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 border border-gray-200 px-2.5 sm:px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span className="hidden xs:inline">Ver dados</span>
                      </button>
                      <button
                        onClick={() => setSelected({ item: s, tab: "aprovar" })}
                        className="flex items-center gap-1.5 text-xs font-semibold text-green-700 bg-green-50 border border-green-200 px-2.5 sm:px-3 py-1.5 rounded-lg hover:bg-green-100 transition-colors whitespace-nowrap"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span className="hidden xs:inline">Aprovar</span>
                      </button>
                      <button
                        onClick={() => setSelected({ item: s, tab: "recusar" })}
                        className="flex items-center gap-1.5 text-xs font-semibold text-red-600 bg-red-50 border border-red-200 px-2.5 sm:px-3 py-1.5 rounded-lg hover:bg-red-100 transition-colors whitespace-nowrap"
                      >
                        <UserX className="w-3.5 h-3.5" />
                        <span className="hidden xs:inline">Recusar</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      {selected && (
        <ModalDetalhes
          item={selected.item}
          initialTab={selected.tab}
          onClose={() => setSelected(null)}
          onApproved={handleApproved}
          onRejected={handleRejected}
        />
      )}
    </div>
  );
}
